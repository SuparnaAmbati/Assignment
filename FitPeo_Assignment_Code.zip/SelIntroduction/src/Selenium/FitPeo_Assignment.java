package Selenium;
import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.Point;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.RemoteWebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.github.bonigarcia.wdm.WebDriverManager;
public class FitPeo_Assignment {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		// ChromeDriver executable
		WebDriverManager.chromedriver().setup();	
		// Initialize ChromeDriver
        WebDriver driver= new ChromeDriver();
        //Maximize the Chrome window
        driver.manage().window().maximize();
        // Initialize WebDriverWait with a timeout of 5 seconds
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(5));
        
        
        
        // 1. Navigate to the FitPeo Homepage
        driver.get("https://www.fitpeo.com");
        
        
        
		//2.Navigate to the Revenue Calculator Page:From the homepage, navigate to the Revenue Calculator Page.
        // Wait for the element to be clickable and then click on Revenue Calculator Page
        WebElement revenueCalculatorLink = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[text()=\"Revenue Calculator\"]")));
        revenueCalculatorLink.click();
        
        
        
        
        // 3.Scroll Down to the Slider section:Scroll down the page until the revenue calculator slider is visible.
        // Wait for the visibility of the locator and identify it
        WebElement sliderSection = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[contains(@class,\"MuiSlider-root MuiSlider\")]"))); 
        //Highlight the slider section
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("arguments[0].style.border='3px solid red';", sliderSection);
        
        
        
        
        //4.Adjust the Slider:Adjust the slider to set its value to 820. we’ve highlighted the slider in red color, Once the slider is moved the bottom text field value should be updated to 820
        WebElement slider = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[contains(@class,\"MuiSlider-thumb MuiSlider\")]")));
        Actions actions = new Actions(driver);
        //Drag the slider to it's x-axis/co-ordinate
        actions.dragAndDropBy(slider, 93, 0);
        Thread.sleep(5000);
        
        
        
        //5.Update the Text Field: Click on the text field associated with the slider and Enter the value 560 in the text field. Now the slider also should change accordingly 
        //Locate text field
        WebElement patients_count = driver.findElement(By.xpath("//input[contains(@class,\"MuiInputBase-input\")]"));
        Thread.sleep(5000);
        actions.moveToElement(patients_count).click().perform();
        Thread.sleep(3000);
        //Clear the text field
        js.executeScript("arguments[0].value = '';", patients_count);
        Thread.sleep(3000);
        actions.moveToElement(patients_count).click().perform();
        Thread.sleep(3000);
        //Enter 560 in the text field
        patients_count.sendKeys("560");
        Thread.sleep(3000);
       
        
        
        
        //6.Validate Slider Value:Ensure that when the value 560 is entered in the text field, the slider's position is updated to reflect the value 560.
        //Get the updated slider value
        WebElement CurrentSliderValue= driver.findElement(By.xpath("//span[contains(@class,\"MuiSlider-thumb MuiSlider\")]/input"));
        String UpdatedSliderValue = CurrentSliderValue.getAttribute("value");
        if(UpdatedSliderValue.equals("560"))
        	System.out.println("Slider updated succesfully");
        else
        	System.out.println("Slider not updated succesfully " + UpdatedSliderValue);
        Thread.sleep(3000);
        
        
        
        
        
        //7.Select CPT Codes:	Scroll down further and select the checkboxes for CPT-99091, CPT-99453, CPT-99454, and CPT-99474.
        String[] cptCodes = {"CPT-99091", "CPT-99453", "CPT-99454", "CPT-99474"};
        // Iterate over each CPT code
        for (String cptCode : cptCodes) {
            // Click the checkbox associated with each CPT code
            WebElement checkbox = driver.findElement(By.xpath("//p[contains(text(),'" + cptCode + "')]//parent::div/label/span/input[@type='checkbox']"));
            Thread.sleep(3000);
            checkbox.click();
            // Double check- Click the checkbox if it is not already selected
            if (!checkbox.isSelected()) {
                checkbox.click();
            }
        }
        
        
        
        
        //8.Validate Total Recurring Reimbursement:
        //9.Verify that the header displaying Total Recurring Reimbursement for all Patients Per Month: shows the value $110700.	
        WebElement header = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//p[contains(text(), 'Total Recurring Reimbursement for all Patients Per Month:')]")));
        Thread.sleep(3000);
        // Retrieve the Total Recurring Reimbursement:
        String headerText = header.getText();
        Thread.sleep(3000);
        // Validate the Total Recurring Reimbursement:
        if (headerText.contains("$110700")) {
            System.out.println("Validation Passed: The header displays the correct value $110700.");
        } else {
            System.out.println("Validation Failed: The header value is " + headerText + ", expected $110700.");
        }
        
    driver.close();    
    } 
    } 
        
    
    	


